Thank you for purchasing my theme!

Open folder Documentation and drag-and-drop index.html into any browser to view the theme documentation.
Edit and upload your theme from folder Template into your web server and enjoy!

Please contact me at tonybogdanov@gmail.com if you are experiencing any difficulties in using the template or the provided documentation, so we can resolve them in the fastest way possible.

Don't forget to comment and rate the item if you have enjoyed it!