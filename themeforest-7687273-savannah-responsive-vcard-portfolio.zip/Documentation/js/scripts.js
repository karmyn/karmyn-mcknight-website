(function($) {
    "use strict";
    
    $('nav a').bind('click', function(e) {
        var $this   = $(this);
        if('#!' === $this.attr('href').substring(0, 2)) {
            e.preventDefault();
            $('nav li.active').removeClass('active');
            $this.parents('li').addClass('active');
            //$('section').load($this.attr('href').substring(2));
            $('iframe').attr('src', $this.attr('href').substring(2));
            history.pushState({}, "", $this.attr('href'));
        }
    });
    
    if(0 < location.hash.length) {
        $('a[href="' + location.hash + '"]').triggerHandler('click');
    }
})(jQuery);